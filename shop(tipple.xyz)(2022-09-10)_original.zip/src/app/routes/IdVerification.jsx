import React, {useEffect, useState} from 'react';
import { useSelector, useDispatch } from 'react-redux';
import NavigationContainer from '../components/Generic/NavigationContainer'
import Page from "../components/Page";
import styles from './IdVerification.module.scss'
import VerificationSelect from "../components/user-verification/VerificationSelect";
import PassportVerification from "../components/user-verification/PassportVerification";
import LicenseVerification from "../components/user-verification/LicenseVerification";
import { idVerification, idVerificationSuccess } from 'app/resources/action/IdVerification';

const verificationType = {
    LICENSE : 'LICENCE',
    PASSPORT : 'PASSPORT'
}

const IdVerification = props => {
    const [step, setStep] = useState(1);
    const [type, setType] = useState();
    const [country, setCountry] = useState();
    const dispatch = useDispatch();
    const auth = useSelector(state => state.auth);
    const idverificationflag = useSelector(state => state.idverification.idverificationflag);
    // dispatch(idVerificationSuccess(1))

    useEffect(() => {
        const script = document.createElement("script");
        script.src = "https://mtf.assets.idservice.com/aus/lib/mids-1.2.0.js";
        script.async = true;
        script.id = "midsLib"
        document.body.appendChild(script);
    }, [])

    const handleLicenseVerification = (formValues) => {

        let licenceData = {
            firstName: formValues.firstName,
            lastName: formValues.lastName,
            dob: formValues.dateOfBirth.split('/').reverse().join('-'),
            idType: "LICENCE",
            idNumber: formValues.licenseNumber,
            idState: formValues.state,
            idCountry: "AUS"
        };

        dispatch(idVerificationSuccess(1))
        dispatch(idVerification(licenceData, auth))

    };

    const handlePassportVerification = (formValues) => {
        
        let passportData = {
            firstName: formValues.firstName,
            lastName: formValues.lastName,
            dob: formValues.dateOfBirth.split('/').reverse().join('-'),
            idType: "PASSPORT",
            idNumber: formValues.passportNumber,
            idState: "",
            idCountry: "AUS"
        };
        dispatch(idVerificationSuccess(1))
        dispatch(idVerification(passportData, auth))
        
    };

    return (
        <Page>
        <NavigationContainer>
            { step === 1 && <div className={styles.container}>
            <h4>Age Verification is required to continue</h4>
            <p>We partner with ID, a secure digital identity service by Mastercard. With ID, you're in control of your identity data</p>
                <a href='https://www.optus.com.au/customer-extras/mastercard-id' className={styles.helpText}>Learn more about ID</a>
            <div className="jumbotron main">
                <div id="mids"
                     className="mids-dark mids-corner-radius-8px mids-cta-continue en-US"
                     callback_function="rpFunction"
                     scopes="ageOver(18):0:365"
                     redirect_uri="https://tipple.xyz/verify/identification"
                     country_code="AU"
                     flow="DWEB2APP"
                     response_type="code"
                     client_id="zeETEms9EjoHrQv5Yku3uB4aiqxbIURCDrkDtDiCfbb41408"
                     code_challenge="OHTD1YV3g4EnN5e42ZA3i_gu5ccpLw5OwmzSHactZ_U"
                     code_challenge_method="S256"
                     nonce="f90f675c-7b48-491a-8354-4daa6b00c767"
                     rp_name="Tipple"
                     locale="en-AU"
                     rp_logo_url="https://content.tipple.com.au/tipple/logo/tipple_rp_logo.png"
                     region="AU"
                     sub_rp_id="ID_OF_SUB_RP_IF_RP_RESELLER"
                     />
            </div>
                <div>
                    <hr />
                </div>
                <h6>Don't have ID?</h6>
                <p>You can do a one-time verification. You will have the option to create a reusable identity after checkout.</p>
                <button onClick={() => setStep(2)}>Verify my details</button>
            </div> }
            { step === 2 && <VerificationSelect onContinue={(type, country) => { setStep(3 ); setType(type); setCountry(country)} } /> }
            { step === 3 && type === verificationType.LICENSE  && <LicenseVerification displaying={idverificationflag} onSubmit={handleLicenseVerification} />}
            { step === 3 && type === verificationType.PASSPORT  && <PassportVerification displaying={idverificationflag} onSubmit={handlePassportVerification}/>}
        </NavigationContainer>
        </Page>
    );
};

export default IdVerification;
