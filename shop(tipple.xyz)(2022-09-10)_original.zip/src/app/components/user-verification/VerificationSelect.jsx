import React, { useState } from 'react';
import ReactFlagsSelect from "react-flags-select";
import classNames from "classnames";
import styles from './VerificationSelect.module.scss';

const verificationType = {
    LICENCE : 'LICENCE',
    PASSPORT : 'PASSPORT'
}

const VerificationSelect = ({ onContinue }) => {
    const [idType, setIdType] = useState();
	const [select, setSelect] = useState("AU");
	const onSelect = (code) => {
		setSelect(code);
		setIdType();
	}

    return (
        <div>
            <h6>Select issuing country/region</h6>
			<ReactFlagsSelect
				selected={select}
				onSelect={onSelect}
				className={styles.countrycontainer}
				// countries={["ALA", "ZWE"]}
				/*showSelectedLabel={showSelectedLabel}
				selectedSize={selectedSize}
				showOptionLabel={showOptionLabel}
				optionsSize={optionsSize}
				placeholder={placeholder}
				searchable={searchable}
				searchPlaceholder={searchPlaceholder}
				alignOptionsToRight={alignOptionsToRight}
				fullWidth={fullWidth}
				disabled={disabled} */
			/>
            <h6>Select ID type</h6>
            <p>Use a valid government-issued photo ID</p>
            <div>
				{ (select==="AU") ? 
				<div className={ classNames( styles.container, idType === verificationType.LICENCE ? styles.active : "")} onClick={() => setIdType(verificationType.LICENCE)} >
                    <div><img src='/static/assets/img/license.png' alt='licence'/>&nbsp;<label>Licence</label></div> 
                </div>: ""
				}
                
                <div className={classNames( styles.container, idType === verificationType.PASSPORT ? styles.active : "")}
                     onClick={() => setIdType(verificationType.PASSPORT)}>
                    <div><img src='/static/assets/img/passport.png' alt='passport'/>&nbsp;<label>Passport</label></div>
                </div>
            </div>
            <div>
            <button disabled={idType ? false : true } className={styles.btnContinue} onClick={() => onContinue(idType, select)}>Continue</button>
            </div>
        </div>
    );
};

VerificationSelect.propTypes = {

};

export default VerificationSelect;
