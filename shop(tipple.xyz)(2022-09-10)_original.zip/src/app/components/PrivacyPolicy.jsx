import React from 'react';
import styles from './PrivacyPolicy.module.scss';
import { useSelector } from 'react-redux';
import Markdown from 'markdown-to-jsx';

const PrivacyPolicy = ({section}) => {
    const theme = useSelector(store => store.theme);
    const content = theme.disclaimers[section] || '';

    return <div className={styles.privacy}>
        <Markdown>{content}</Markdown>
    </div>;
}

export default PrivacyPolicy;

