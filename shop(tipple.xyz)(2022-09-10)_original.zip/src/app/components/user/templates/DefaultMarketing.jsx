import React from 'react';

const MarketingCheckbox = () => {
    return (
        <>
            I'd like to receive offers and deals by email
        </>
    );
};

export default MarketingCheckbox;