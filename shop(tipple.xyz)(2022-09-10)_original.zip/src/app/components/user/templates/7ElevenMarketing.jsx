import React from 'react';

const MarketingCheckbox = () => {
    return (
        <>
            I consent to 7-Eleven collecting my personal information and sending me electronic direct marketing.
        </>
    );
};

export default MarketingCheckbox;